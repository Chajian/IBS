<template>
<div>
	<dir class="head"></dir>
	
	<dir class="content">
		<h1>{{welcome}}</h1>
		
		
	</dir>
</div>
</template>

<script>
export default{
	data:function(){
		return {
			welcome:'欢迎来到IBS'
		}
	},
	methods:{
		registerAccount:function(account,pass){
			
		}
	}
	
	
}
</script>

<style>
</style>
