<template>
<div class="loginmain">
    <div>
<!--        <div class="nav">-->
<!--            <router-link to="/navigat"></router-link>-->
<!--             <router-link to="/about">About</router-link>-->
            <nava id="login_nava"></nava>
<!--        </div>-->
<!--        <router-view/>-->
    </div>
</div>
</template>

<script>
import nava from '../components/navigation'
export default{
    components:{
        nava
    },
    mounted() {
        nava.jjw = '100%'//我想动态修改组件的大小
        cons
    }
}
</script>

<style>
.loginmain{
    width: 100%;
    height: auto;
}
/*.nav{*/
/*    align-content: center;*/
/*    width: 100%;*/
/*    height: auto;*/
/*}*/
div{
    width: 100%;
}
</style>
