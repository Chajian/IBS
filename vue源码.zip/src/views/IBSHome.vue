<template>
<div>
<div class="top">
	<ul>
		<li class="topPadding"></li>
		<li class="title-top topPadding" style="width: 14%;">
			<img src="../assets/home/title.png" width="100%" alt="">
		</li>
		<li class="topPadding"></li>
		<li class="topPadding"></li>
		<li class="topPadding"></li>
		<li class="topPadding"></li>
		<li class="topPadding"></li>
		<li class="topPadding"></li>
		<li class="topPadding">
			<a class="home" href="http://baidu.com">
				<i class="iconfontOne colorWhite" id="name">&#xe694;</i>
				<br>
				<i class="iconfontTwo colorWhite" id="names">首页</i>
			</a>
		</li>
		<li class="topPadding">
			<a class="luntanneibu" href="http://baidu.com">
				<i class="iconfontOne colorWhite">&#xe731;</i>
				<br/>
				<i class="iconfontTwo colorWhite">公告</i>
			</a>
		</li>
		<li class="topPadding">
			<a class="luntanneibu" href="http://baidu.com">
				<i class="iconfontOne colorWhite">&#xe65e;</i>
				<br/>
				<i class="iconfontTwo colorWhite">活动</i>
			</a>
		</li>
		<li class="topPadding">
			<a class="luntanneibu" href="http://baidu.com">
				<i class="iconfontOne colorWhite">&#xe624;</i>
				<br/>
				<i class="iconfontTwo colorWhite">团队</i>
			</a>
		</li>
        <li class="topPadding">
            <a class="luntanneibu">
                <router-link to="/login">
                    <i class="iconfontOne colorWhite">&#xe624;</i>
                    <br/>
                    <i class="iconfontTwo colorWhite">登陆</i>
                </router-link>
            </a>
        </li>
	</ul>
</div>
<div class="image">
    <button id="directionLeft" class="direction-left">
        <i class="iconfontOne left">
            &#xe643;
        </i>
    </button>
    <div class="Introduction">

    </div>
    <div style="width: 5400px;height: 800px;overflow: hidden;">
    <img class="images imageLi" src="../assets/home/background.jpg" style="margin: 0 0;padding: 0;" alt="">
    <img class="images imageLi" src="../assets/home/background.jpg" style="margin: 0 0;padding: 0;" alt="">
    <img class="images imageLi" src="../assets/home/background.jpg" style="margin: 0 0;padding: 0;" alt="">
    </div> 
    <button id="directionRight" class="direction-right">
        <i class="iconfontOne right">
            &#xe640;
        </i>
    </button>
</div>
<div class="placard">
    <img src="../assets/home/placard.png" width="1800px" alt="">
    <div class="NoticeBlock">
        <div class="NoticeTop">
            <a class="new_chat new">杂谈</a>
            <a class="new_activity new">活动</a>
            <a class="new_notice new">公告</a>
            <a class="new_new new">最新</a>
        </div>
        <div class="banner"></div>
        <div class="new_show">
            <div class="news"><a class="aFile">1</a></div>
            <div class="news"><a class="aFile">1</a></div>
            <div class="news"><a class="aFile">1</a></div>
            <div class="news"><a class="aFile">1</a></div>
            <div class="news"><a class="aFile">1</a></div>
            <div class="news" style="float: end"><a class="aFile" >1</a></div>
        </div>
    </div>
</div>
<div class="Ranking">
    <div class="dead RankingBlock ">
        <i class="iconfontTwo" style="color: white;">意外死亡</i>
        <ul class="ulInlineBlock RankingPosition">
            <ol></ol>
            <ol></ol>
            <ol></ol>
            <ol></ol>
            <ol></ol>
            <ol></ol>
            <ol></ol>
            <ol></ol>
            <ol></ol>
            <ol></ol>
        </ul>
    </div>
    <div class="win RankingBlock">
        <i class="iconfontTwo RankingPosition" style="color: white;">K/D</i>
        <ul class="ulInlineBlock">
            <ol></ol>
            <ol></ol>
            <ol></ol>
            <ol></ol>
            <ol></ol>
            <ol></ol>
            <ol></ol>
            <ol></ol>
            <ol></ol>
            <ol></ol>
        </ul>
    </div>
    <div class="KDA RankingBlock">
        <i class="iconfontTwo RankingPosition" style="color: white;">胜场最多</i>
        <ul class="ulInlineBlock">
            <ol></ol>
            <ol></ol>
            <ol></ol>
            <ol></ol>
            <ol></ol>
            <ol></ol>
            <ol></ol>
            <ol></ol>
            <ol></ol>
            <ol></ol>
        </ul>
    </div>
</div>
<div class="playGame">
    <div class="Game">
        <div class="ul">
            <div class="ul-i">
                <i class="iconfontTwo" style="color: white;">游戏列表</i>
            </div>
            <ul>
                <li class="ul-li"></li>
                <li class="ul-li"></li>
                <li class="ul-li"></li>
                <li class="ul-li"></li>
            </ul>
        </div>
        <div class="data">

        </div>
    </div>
</div>
</div>

</template>

<script>
export default {
    data:function () {
        return{

        }
    }
}


</script>

<style>
	@import url("../assets/css/mainCss.css");
	@font-face {
		font-family: 'iconfont';
		/* project id 1884106 */
		src: url('http://at.alicdn.com/t/font_1884106_ftd9maoafu6.eot');
		src: url('http://at.alicdn.com/t/font_1884106_ftd9maoafu6.eot?#iefix') format('embedded-opentype'),
		url('http://at.alicdn.com/t/font_1884106_ftd9maoafu6.woff2') format('woff2'),
		url('http://at.alicdn.com/t/font_1884106_ftd9maoafu6.woff') format('woff'),
		url('http://at.alicdn.com/t/font_1884106_ftd9maoafu6.ttf') format('truetype'),
		url('http://at.alicdn.com/t/font_1884106_ftd9maoafu6.svg#iconfont') format('svg');
	}
</style>
